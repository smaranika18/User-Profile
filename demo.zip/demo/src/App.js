// App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ProfileProvider } from "./ProfileContext";
import ProfileForm from "./ProfileForm";
import ProfileTable from "./ProfileTable";

function App() {
  return (
    <ProfileProvider>
      <Router>
        <Routes>
          <Route path="/" element={<ProfileForm />} />
          <Route path="/table" element={<ProfileTable />} />
        </Routes>
      </Router>
    </ProfileProvider>
  );
}

export default App;


