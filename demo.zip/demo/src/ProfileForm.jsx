// components/ProfileForm.jsx
import React, { useState, useContext } from "react";
import { ProfileContext } from "./ProfileContext";
import { useNavigate } from "react-router-dom";
import "./App.css";

const ProfileForm = () => {
  const { addProfile } = useContext(ProfileContext);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    age: "",
    gender: "",
    bio: ""
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};
    if (!form.fullName) newErrors.fullName = "Full Name is required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) newErrors.email = "Valid Email is required";
    if (!form.age || parseInt(form.age) < 18) newErrors.age = "Age must be 18 or above";
    if (!form.gender) newErrors.gender = "Please select a gender";
    if (!form.bio) newErrors.bio = "Bio is required";
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    addProfile(form);
    setSubmitted(true);
    setErrors({});
  };

  return (
    <div className="form-container">
      <h2>User Profile Form</h2>
      <form onSubmit={handleSubmit}>
        <label>Full Name</label>
        <input type="text" name="fullName" value={form.fullName} onChange={handleChange} />
        {errors.fullName && <p className="error">{errors.fullName}</p>}

        <label>Email</label>
        <input type="email" name="email" value={form.email} onChange={handleChange} />
        {errors.email && <p className="error">{errors.email}</p>}

        <label>Age</label>
        <input type="number" name="age" value={form.age} onChange={handleChange} />
        {errors.age && <p className="error">{errors.age}</p>}

        <label>Gender</label>
        <select name="gender" value={form.gender} onChange={handleChange}>
          <option value="">Select</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
        {errors.gender && <p className="error">{errors.gender}</p>}

        <label>Bio</label>
        <textarea name="bio" value={form.bio} onChange={handleChange}></textarea>
        {errors.bio && <p className="error">{errors.bio}</p>}

        <button type="submit">Submit</button>
        <button type="button" onClick={() => navigate("/table")}>View All Profiles</button>
      </form>

      {submitted && (
        <div className="preview">
          <h3>Preview:</h3>
          <p><strong>Name:</strong> {form.fullName}</p>
          <p><strong>Email:</strong> {form.email}</p>
          <p><strong>Age:</strong> {form.age}</p>
          <p><strong>Gender:</strong> {form.gender}</p>
          <p><strong>Bio:</strong> {form.bio}</p>
        </div>
      )}
    </div>
  );
};

export default ProfileForm;