
// components/ProfileTable.jsx
import React, { useContext } from "react";
import { ProfileContext } from "./ProfileContext";
import "./App.css"; 

const ProfileTable = () => {
  const { profiles } = useContext(ProfileContext);

  return (
    <div className="table-container">
      <h2>Submitted Profiles</h2>
      <table>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Bio</th>
          </tr>
        </thead>
        <tbody>
          {profiles.map((profile, index) => (
            <tr key={index}>
              <td>{profile.fullName}</td>
              <td>{profile.email}</td>
              <td>{profile.age}</td>
              <td>{profile.gender}</td>
              <td>{profile.bio}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProfileTable;
